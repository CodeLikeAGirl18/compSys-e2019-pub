/*
  Support functions. Just one for now.
*/

// print an error and exit
void error(const char* message);

